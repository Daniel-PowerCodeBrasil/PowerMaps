/*! For license information please see bundle.js.LICENSE.txt */
var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad;(()=>{"use strict";var e={d:(t,o)=>{for(var r in o)e.o(o,r)&&!e.o(t,r)&&Object.defineProperty(t,r,{enumerable:!0,get:o[r]})},o:(e,t)=>Object.prototype.hasOwnProperty.call(e,t),r:e=>{"undefined"!=typeof Symbol&&Symbol.toStringTag&&Object.defineProperty(e,Symbol.toStringTag,{value:"Module"}),Object.defineProperty(e,"__esModule",{value:!0})}},t={};e.r(t),e.d(t,{HeatMapControl:()=>r});const o=Reactv16;class r{init(e,t,o){}updateView(e){return o.createElement("div",{style:{width:"100%",height:"100%",display:"flex",alignItems:"center",justifyContent:"center",background:"#0078d4",color:"#fff",fontFamily:"Segoe UI, Arial, sans-serif",fontSize:"18px"}},"PowerMaps HeatMap (virtual diagnostic)")}getOutputs(){return{}}destroy(){}}pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad=t})();
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('PowerMapsBR.HeatMapControl', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.HeatMapControl);
} else {
	var PowerMapsBR = PowerMapsBR || {};
	PowerMapsBR.HeatMapControl = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.HeatMapControl;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}